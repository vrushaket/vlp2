INF = 9999999
V = 5
G = [
        #A  B  C  D  E
        [0, 0, 3, 0, 0],    #A 
        [0, 0, 10, 4, 0],   #B 
        [3, 10, 0, 2, 6],   #C 
        [0, 4, 2, 0, 1],    #D 
        [0, 0, 6, 1, 0]     #E 
    ]

visited = [0, 0, 0, 0, 0]
no_of_edge = 0
visited[0] = True

print("Edge : Weight\n")
while (no_of_edge < V - 1):
    # For every vertex in the set S, find the all adjacent vertices, calculate the distance from the vertex visited at step 1.
    # if the vertex is already in the set S, discard it otherwise choose another vertex nearest to visited vertex  at step 1.
    minimum = INF
    x = 0
    y = 0
    for i in range(V):
        if visited[i]:
            for j in range(V):
                if ((not visited[j]) and G[i][j]):  # not in visited and there is an edge
                    if minimum > G[i][j]:
                        minimum = G[i][j]
                        x = i
                        y = j
                        
    print(str(x) + "-" + str(y) + " : " + str(G[x][y]))
    visited[y] = True
    no_of_edge += 1
    

# time complexity       O(E log V)
# the number of egde in minimum spanning tree will be always less than(V - 1)
