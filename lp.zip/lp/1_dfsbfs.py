
class DFSBFS:
    def __init__(self):
        self.graph = [
            [1,2],
            [0,3,4],
            [0,5],
            [1],
            [1],
            [2]
        ]
        
    def dfs(self,graph,stack,visited):
        element = stack.pop()
        visited.append(element)
        print(element)
        for i in graph[element]:
            if i not in visited:
                stack.append(i)
                self.dfs(graph,stack,visited)
                
    
    def bfs(self,graph,queue,visited):
        if queue:
            element = queue.pop(0)
            visited.append(element)
            print(element)
            for i in graph[element]:
                if i not in visited:
                    queue.append(i)
            self.bfs(graph,queue,visited)
                
    
    def fun_call(self):
        stack = [0]
        visited = []
        self.dfs(self.graph,stack,visited)
        print()
        queue = [0]
        visited = []
        self.bfs(self.graph,queue,visited)
        

DFSBFS().fun_call()