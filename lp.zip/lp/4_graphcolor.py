V = 4
graph = [   #A  B  C  D
        	[0, 1, 1, 1],  	#A
            [1, 0, 1, 0], 	#B
            [1, 1, 0, 1], 	#C
            [1, 0, 1, 0]	#D
        ]
        
def isSafe(vertex, colors, c):
	for i in range(V):
		if graph[vertex][i] == 1 and colors[i] == c:
			return False
	return True
	
def graphcolorsUtil(m, colors, vertex):
	if vertex == V:
		return True

	for c in range(1, m + 1):
		if isSafe(vertex, colors, c) == True:
			colors[vertex] = c
			if graphcolorsUtil(m, colors, vertex + 1) == True:
				return True
			colors[vertex] = 0

def graphcolorsing(m):
	colors = [0] * V
	if graphcolorsUtil(m, colors, 0) == None:
		return False

	print ("Solution exist and Following are the assigned colorss:")
	for c in colors:
		print (c,end=' ')
	return True
 
graphcolorsing(3)

