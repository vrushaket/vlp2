from sklearn.model_selection import cross_validate


name = input("Please enter your name : ")
print("Welcome ",name,", please provide necessary inputs to help you diagonse properly.")
print()

question_set1=[
    'What is your age?',
    'What is your oxygen level?',
    'What is your body temperature in celcius?'
]
age,o2,temp = (0,0,0)
qno = 1
for question in question_set1:
    print(question)
    if qno == 1:
        age = int(input())
    if qno == 2:
        o2 = float(input())
    if qno == 3:
        temp = float(input())
    qno+=1

print("Enter answer in y/n")
question_set2=[
    'Are you feeling tired?',
    'Are you having runny nose?',
    'Are you experiencing sneezing?',
    'Are you feeling cold?',
    'Are you feeling weak?',
    'Are you having head ache?',
    'Are you not able to take breathe comfortably?',
    'Are you feeling body pain?',
    'Are you not able to taste or smell?',
]

covid =0
flu=0
cold =0
pneumonia =0

qno=0
for question in question_set2:
    print(question)
    ans = input()
    if qno ==0 and ans.lower() == 'y':
        covid+=1
        flu+=1
        cold+=1
        pneumonia+=1
        
    if qno ==1 and ans.lower() == 'y':
        covid+=1
        cold+=1
        pneumonia+=1
        
    if qno ==2 and ans.lower() == 'y':
        covid+=1
      
        cold+=1
       
    
    if qno ==3 and ans.lower() == 'y':
        
        cold+=1
        pneumonia+=1
    
    if qno ==4 and ans.lower() == 'y':
        covid+=1
        flu+=1
        cold+=1
        pneumonia+=1
    
    if qno ==5 and ans.lower() == 'y':
        covid+=1
        flu+=1
        cold+=1
        
    
    if qno ==6 and ans.lower() == 'y':
        covid+=1

        pneumonia+=1
    
    if qno ==7 and ans.lower() == 'y':
        covid+=1
        flu+=1
       
    if qno ==8 and ans.lower() == 'y':
        covid+=1
        flu+=1 
    qno+=1

if(cold ==0 and covid==0 and flu==0 and pneumonia ==0):
    print("You are healty")
else:
    max = -1
    max_idx = 0
    dis = [cold,covid,flu,pneumonia]
    disease = ''
    for i in range(len(dis)):
        if max < dis[i]:
            max = dis[i]
            max_idx = i
    
    if max_idx == 0:
        print('cold')
    if max_idx == 1:
        print('covid')
    if max_idx == 2:
        print('flu')
    if max_idx == 3:
        print('pneumonia')
            
    